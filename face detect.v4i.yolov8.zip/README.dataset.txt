# face detect > 2024-04-18 5:09pm
https://universe.roboflow.com/yolo-ccdgk/face-detect-i4e0c

Provided by a Roboflow user
License: CC BY 4.0

